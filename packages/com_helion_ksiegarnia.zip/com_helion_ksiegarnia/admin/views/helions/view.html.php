<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla view library
//jimport('joomla.application.component.view');
 
/**
 * HelloWorlds View
 */
class HelionViewHelions extends JViewLegacy
{
	/**
	 * HelloWorlds view display method
	 * @return void
	 */
	function display($tpl = null) 
	{
		// Display the template
		parent::display($tpl);
	}
}
?>