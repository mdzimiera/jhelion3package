<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla controller library
//jimport('joomla.application.component.controller');

JLoader::register('HelionHelper', JPATH_COMPONENT . '/helpers/helper.php');

/**
 * Helion Component Controller
 */
class HelionController extends JControllerLegacy
{
    
}

?>