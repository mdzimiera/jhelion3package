<?php

class modHelionSerieHelper
{

}
?>
