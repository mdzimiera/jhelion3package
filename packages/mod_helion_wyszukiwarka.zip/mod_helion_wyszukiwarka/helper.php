<?php

class modHelionWyszukiwarkaHelper
{

}
?>
